/*  pulse sequence code - IP_PS2DJDOSY_I*/

#include <standard.h>
#include <chempack.h>

static int	ph1[8] = {0,2,0,2,0,2,0,2},
		ph2[8] = {0,0,0,0,0,0,0,0},
		ph3[8] = {0,0,1,1,2,2,3,3},
		ph4[8] = {0,2,2,0,0,2,2,0};

pulsesequence()
{

   double
   	           dtau = getval("dtau"), 
	           ispediff = getval("ispediff"), 
	           isps = getval("isps"),
	           aaa1 = getval("aaa1"),
	           aaa2 = getval("aaa2"),
   	           nid = getval("nid"),  
   	           isd2 = getval("isd2"),               
                   cycles1, cycles2,cycles3,
	           bigtau = getval("bigtau"),
             	   tau = getval("tau"),
	           iscpmg = getval("iscpmg"),
             	   ispe = getval("ispe"),

						isDoneshot = getval("isDoneshot"),
						oneshot45_flg = getval("oneshot45_flg"),
						kappa = getval("kappa"),
						delcor = getval("delcor"),
isjacq = getval("isjacq"),
i = getval("i"),
np2 = getval("np2"),
np1 = getval("np1"),
retdly = getval("retdly"),
Gz4 = getval("Gz4"),
gt4 = getval("gt4"),
gt6 = getval("gt6"),
             	   isa = getval("isa"),
                    isdosy=getval("isdosy"),
                    del=getval("del"),
                    gt3=getval("gt3"),
                   gzlvl3=getval("gzlvl3"),
		
                   gzlvl4=getval("gzlvl4"),	   
                   gt0=getval("gt0"),
                   gzlvl0=getval("gzlvl0"),
                   gt5=getval("gt5"),
                   gzlvl5=getval("gzlvl5"),
                   isdiff=getval("isdiff"),
                   isbpp=getval("isbpp"),
                   gstab0=getval("gstab0"),
                   del0=getval("del0"),
                   issspul=getval("issspul"),

                   gt1 = getval("gt1"),
		   gzlvl1=getval("gzlvl1"),
		   gt2 = getval("gt2"),
		   gzlvl2=getval("gzlvl2"),
		   selpwrPS = getval("selpwrPS"),
		   selpwPS = getval("selpwPS"),
		   gzlvlPS = getval("gzlvlPS"),
		   droppts=getval("droppts"),
		   gstab = getval("gstab");
   int 		   prgcycle=(int)(getval("prgcycle")+0.5);
   char		   selshapePS[MAXSTR];

//synchronize gradients to srate for probetype='nano'
//   Preserve gradient "area"
        gt1 = syncGradTime("gt1","gzlvl1",1.0);
        gzlvl1 = syncGradLvl("gt1","gzlvl1",1.0);
	gt2 = syncGradTime("gt2","gzlvl2",1.0);
        gzlvl2 = syncGradLvl("gt2","gzlvl2",1.0);

   getstr("selshapePS",selshapePS);

  assign(ct,v17);
  assign(zero,v18);
  assign(zero,v19);

  if (getflag("prgflg") && (satmode[0] == 'y') && (prgcycle > 1.5))
    {
        hlv(ct,v17);
        mod2(ct,v18); dbl(v18,v18);
        if (prgcycle > 2.5)
           {
                hlv(v17,v17);
                hlv(ct,v19); mod2(v19,v19); dbl(v19,v19);
           }
     }

   settable(t1,8,ph1);
   settable(t2,8,ph2);
   settable(t3,8,ph3);
   settable(t4,8,ph4);

   getelem(t1,v17,v1);
   getelem(t2,v17,v2);
   getelem(t3,v17,v3);
   getelem(t4,v17,v4);
   assign(v4,oph);

   assign(v1,v6);
   add(oph,v18,oph);
   add(oph,v19,oph);

/* calculate 'big tau' values for cpmg */
   cycles1 = bigtau/(2.0*tau);
   cycles1 = (double)((int)((cycles1/2.0))*2.0);
   initval(cycles1,v11);

/* calculate 'big tau' values for pe */
   cycles2 = bigtau/(2.0*tau);
   cycles2 = (double)((int)((cycles2/2.0) + 0.5)) * 2.0;
   cycles2 = cycles2/2.0;
   initval(cycles2,v12);


/* calculate 'v13' values for dosy-del */
   cycles3 = (bigtau-2.0*tau)*0.5/(2.0*tau);
   cycles3 = (double)((int)((cycles3/2.0) + 0.5)) * 2.0;

   initval(cycles3,v13);
/* calculate 'big tau' values for pe2 */
   cycles2 = (bigtau-8*tau)/(4.0*tau);
   //cycles2 = (double)((int)((cycles2/2.0) + 0.5)) * 2.0;
   //cycles2 = cycles2/2.0;
   initval(cycles2,v14);

/* BEGIN THE ACTUAL PULSE SEQUENCE */
   status(A);
      obsoffset(tof);
      obspower(tpwr);

if(issspul==1)

{  
	zgradpulse(gzlvl0,gt0);

	rgpulse(50*pw,zero,rof1,rof2);
	rgpulse(50*pw,zero,rof1,rof2);

	zgradpulse(gzlvl0,gt0);

}


   delay(5.0e-5);
   if (getflag("sspul"))
        steadystate();

   if (satmode[0] == 'y')
     {
        if ((d1-satdly) > 0.02)
                delay(d1-satdly);
        else
                delay(0.02);
        if (getflag("slpsat"))
           {
                shaped_satpulse("relaxD",satdly,v6);
                if (getflag("prgflg"))
                   shaped_purge(v1,v6,v18,v19);
           }
        else
           {
                satpulse(satdly,v6,rof1,rof1);
                if (getflag("prgflg"))
                   purge(v1,v6,v18,v19);
           }
     }

   else

        delay(d1);

   if (getflag("wet"))
     wet4(zero,one);

   status(B);
      obspower(tpwr);
	if (isDoneshot==1)
    {
        zgradpulse(-1.0*gzlvl4,gt4);
        delay(gstab);
    }
      rgpulse(pw, v1, rof1, rof2);
//delay(0.000005);a=1

//BPPSTE diffusion
if(isdiff==1)
{

if(isbpp==1)
{zgradpulse(gzlvl5,gt5/2.0);
         delay(gstab0);

	 rgpulse(pw*2.0, v15, rof1, rof1);	

zgradpulse(-1.0*gzlvl5,gt5/2.0);
         delay(gstab0);
}
else
{
zgradpulse(gzlvl5,gt5);
         delay(gstab0);
}

rgpulse(pw, v13, rof1, 0.0);		

        delcor = del0-4.0*pw-3.0*rof1-gt5-2.0*gstab0;
         if (satmode[1] == 'y')
          {
           obspower(satpwr);
           if (satfrq != tof) obsoffset(satfrq);
           rgpulse(delcor,zero,rof1,rof1);
           if (satfrq != tof) obsoffset(tof);
           obspower(tpwr);
          }
         else delay(delcor);     

rgpulse(pw, v14, rof1, 0.0);		

if(isbpp==1)
{zgradpulse(gzlvl5,gt5/2.0);
         delay(gstab0);

	 rgpulse(pw*2.0, v15, rof1, rof1);	

zgradpulse(-1.0*gzlvl5,gt5/2.0);
         delay(gstab0);
}
else
{
zgradpulse(gzlvl5,gt5);
         delay(gstab0);
}

}

//BPPSTE diffusion

if(isa==1)
{

if(iscpmg==1)
{
   starthardloop(v11);
      delay(tau - pw - rof2);
      rgpulse(2*pw,one,rof2,rof2); 
      delay(tau - pw - rof2);
   endhardloop();
}
if(isDoneshot==1)
{

   if (gt1>0 && gzlvl1>0) 
      {
   	 //rgpulse(pw, one, rof1, 0.0);		/* first 90, v1 */
		 zgradpulse(gzlvl3*(1.0-kappa),gt3/2.0);/*1st main gradient pulse*/
   	 delay(gstab);
	 	 rgpulse(pw*2.0, one, rof1, 0.0);	/* first 180, v2 */
		 zgradpulse(-1.0*gzlvl3*(1.0+kappa),gt3/2.0);/*2nd main grad. pulse*/
   	 delay(gstab);
   	 rgpulse(pw, one, rof1, 0.0);		/* second 90, v3 */

       zgradpulse(gzlvl3*2.0*kappa,gt3/2.0);/* Lock refocussing pulse*/
   	 delay(gstab);

       zgradpulse(gzlvl4,gt4);/* Spoiler gradient balancing pulse */
   	 delay(gstab);

       delcor = del-4.0*pw-3.0*rof1-2.0*gt3-5.0*gstab-gt4;

       delay(del-4.0*pw-3.0*rof1-2.0*gt3-5.0*gstab-gt4); /* diffusion delay */

       zgradpulse(2.0*kappa*gzlvl3,gt3/2.0);/*Lock refocussing pulse*/
   	 delay(gstab);
   	 rgpulse(pw, one, rof1, 0.0);		/* third 90, v4 */

       zgradpulse(gzlvl3*(1.0-kappa),gt3/2.0);/*3rd main gradient pulse*/
   	 delay(gstab);
	    rgpulse(pw*2.0, one, rof1, rof1);	/* second 180, v5 */

       zgradpulse(-1.0*(1.0+kappa)*gzlvl3,gt3/2.0);/*4th main grad. pulse*/
	if (oneshot45_flg == 1)
	{
   	 delay(gstab);
	 rgpulse(0.5*pw,one,rof1,rof2);	/* 45-degree pulse, orthogonal to the last 90 */
	}
	else
   	 delay(gstab+2*pw/PI);
      	}
  
}

}
if(ispe==1)
{

if(ispediff==1)
{
 if(aaa1==1)
{
   if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}

   starthardloop(v12);

      delay(tau - pw - rof1);
      rgpulse(2*pw,one,rof1,rof1); 
      delay(tau - pw - rof1);
      rgpulse(pw,one,rof1,rof1); 
      delay(tau - pw - rof1);
      rgpulse(2*pw,one,rof1,rof1); 
      delay(tau - pw - rof1);
   endhardloop();

   if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
}
 if(aaa1==2)
{


   starthardloop(v12);

      delay((tau -gt3- pw - rof1)/2);

   if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      delay((tau -gt3- pw - rof1)/2);

      rgpulse(2*pw,one,rof1,rof1);

      delay((tau -gt3- pw - rof1)/2);
    if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      delay((tau -gt3- pw - rof1)/2);

      rgpulse(pw,one,rof1,rof1); 

      delay((tau -gt3- pw - rof1)/2);
    if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      delay((tau -gt3- pw - rof1)/2);

      rgpulse(2*pw,one,rof1,rof1);
      delay((tau -gt3- pw - rof1)/2);
    if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      delay((tau -gt3- pw - rof1)/2);
   endhardloop();


}
if(aaa1==3)
{


   starthardloop(v12);

      //delay((tau -gt3- pw - rof1)/2);
	delay(0.0005);
   if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      delay((tau -gt3- pw - rof1 - 0.0005));

      rgpulse(2*pw,one,rof1,rof1);

      delay((tau -gt3- pw - rof1 - 0.0005));
    if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      //delay((tau -gt3- pw - rof1)/2);
	delay(0.0005);
      rgpulse(pw,one,rof1,rof1); 
	delay(0.0005);
      //delay((tau -gt3- pw - rof1)/2);
    if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      delay((tau -gt3- pw - rof1 - 0.0005));

      rgpulse(2*pw,one,rof1,rof1);
      delay((tau -gt3- pw - rof1 - 0.0005));
    if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      //delay((tau -gt3- pw - rof1)/2);
	delay(0.0005);
   endhardloop();


 
}
if(aaa1==4)
{

      delay((tau - pw - rof1 - 0.0005));

      rgpulse(2*pw,one,rof1,rof1);

      delay((tau - pw - rof1 - 0.0005));
    
      //delay((tau -gt3- pw - rof1)/2);
	delay(0.0005);
      rgpulse(pw,one,rof1,rof1); 
	delay(0.0005);
      //delay((tau -gt3- pw - rof1)/2);
    if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      delay((tau -gt3- pw - rof1 - 0.0005));

      rgpulse(2*pw,one,rof1,rof1);
      delay((tau -gt3- pw - rof1 - 0.0005));
    if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      //delay((tau -gt3- pw - rof1)/2);
	delay(0.0005);

   starthardloop(v14);

      //delay((tau -gt3- pw - rof1)/2);
	delay(0.0005);
   if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      delay((tau -gt3- pw - rof1 - 0.0005));

      rgpulse(2*pw,one,rof1,rof1);

      delay((tau -gt3- pw - rof1 - 0.0005));
    if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      //delay((tau -gt3- pw - rof1)/2);
	delay(0.0005);
      rgpulse(pw,one,rof1,rof1); 
	delay(0.0005);
      //delay((tau -gt3- pw - rof1)/2);
    if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      delay((tau -gt3- pw - rof1 - 0.0005));

      rgpulse(2*pw,one,rof1,rof1);
      delay((tau -gt3- pw - rof1 - 0.0005));
    if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      //delay((tau -gt3- pw - rof1)/2);
	delay(0.0005);
   endhardloop();

if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      delay((tau -gt3- pw - rof1 - 0.0005));

      rgpulse(2*pw,one,rof1,rof1);

      delay((tau -gt3- pw - rof1 - 0.0005));
    if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
      //delay((tau -gt3- pw - rof1)/2);
	delay(0.0005);
      rgpulse(pw,one,rof1,rof1); 
	delay(0.0005);
      //delay((tau -gt3- pw - rof1)/2);
    
      delay((tau - pw - rof1 - 0.0005));

      rgpulse(2*pw,one,rof1,rof1);
      delay((tau - pw - rof1 - 0.0005));
    
      //delay((tau -gt3- pw - rof1)/2);
	delay(0.0005);
 
}

}
else//ispediff=0
{
 delay(5.0e-6);

   if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}


   starthardloop(v13);
      delay(tau - pw - rof1);
      rgpulse(2*pw,one,rof1,rof1); 
      delay(tau - pw - rof1);
   endhardloop();

      delay(tau - pw - rof1);
      rgpulse(2*pw,one,rof1,rof1);
      delay(tau - pw - rof1); 

   starthardloop(v13);
      delay(tau - pw - rof1);
      rgpulse(2*pw,one,rof1,rof1); 
      delay(tau - pw - rof1);
   endhardloop();

   if(gzlvl3*gt3!=0.0)
{

        rgradient('z',gzlvl3);
        delay(gt3);
        rgradient('z',0.0);

}
}

}//ispe



if(isps==1)
{
if(isd2==1)	
{delay(d2/2.0);}
else
{delay(nid/(sw1*2.0));}
}
        if(isdosy==1)
{
	delay((0.25/sw1) - gt1 - gstab - 2*GRADIENT_DELAY - pw - rof1);
	//zgradpulse(gzlvl1,gt1);

   starthardloop(v13);
      delay(dtau - pw - rof1);
      rgpulse(2*pw,one,rof1,rof1); 
      delay(dtau - pw - rof1);
   endhardloop();


	//rgpulse(2*pw,v2,rof1,rof1);
//	delay(del/2.0-pw-rof1);

   starthardloop(v13);
      delay(dtau - pw - rof1);
      rgpulse(2*pw,one,rof1,rof1); 
      delay(dtau - pw - rof1);
   endhardloop();

	//zgradpulse(gzlvl1,gt1);
	delay((0.25/sw1) - gt1 - gstab - 2*GRADIENT_DELAY - pw - rof1);
}
else
{
     if(isps==1)
{
	delay((0.25/sw1) - gt1 - gstab - 2*pw/PI - rof2 - 2*GRADIENT_DELAY - pw - rof1);
	zgradpulse(gzlvl1,gt1);
	delay(gstab);
	rgpulse(2*pw,v2,rof1,rof1);
	zgradpulse(gzlvl1,gt1);
	delay(gstab);
	delay((0.25/sw1) - gt1 - gstab - 2*GRADIENT_DELAY - pw - rof1);

	delay(gstab);
	zgradpulse(gzlvl2,gt2);
	delay(gstab);
	obspower(selpwrPS);
	rgradient('z',gzlvlPS);
	shaped_pulse(selshapePS,selpwPS,v3,rof1,rof1);
	rgradient('z',0.0);
	delay(gstab);
	obspower(tpwr);
	zgradpulse(gzlvl2,gt2);
	delay(gstab - droppts/sw);

if(isd2==1)	
{delay(d2/2.0);}
else
{delay(nid/(sw1*2.0));}

}

}




 obsoffset(tof);
   status(C);
if(isjacq==0)
{ 
  status(C);
             
}
else
{
 /*delay((retdly-2*selpw-2*gt3-1.5e-5)/2);
	zgradpulse(Gz4,gt3);
		delay(5e-6);
       	 	//rgpulse(2*pw,0,rof1,rof2);

	obsoffset(seltof);
	obspower(selpwr);
	shaped_pulse(selpat,selpw,0,rof1,rof1);
	delay(5e-6);
	//delay(5e-6);
	obsoffset(tof);
	rgradient('z',Gz);
	shaped_pulse(selpat,selpw,0,rof1,rof1);
	rgradient('z',0.0);
	delay(5e-6);
	zgradpulse(Gz4,gt3);
	delay((retdly-2*selpw-2*gt3-1.5e-5)/2);	
obspower(tpwr);*/
                           
  status(C);

 for(i=1;i<np2+1;i++)
{
		obsoffset(tof);
		obspower(tpwr);	
		rcvron();
		//delay(5e-6);
        	acquire(np1,1/sw); 
		//delay(5e-6);
       		rcvroff();     
                delay((retdly-2*pw-2*gt6-1e-5)/2);
       		rgradient('z',Gz4);
       		delay(gt6);
       		rgradient('z',0.0);
		delay(5e-6);
       	 	rgpulse(2*pw,0,rof1,rof2);
		delay(5e-6);
                rgradient('z',Gz4);
       		delay(gt6);
       		rgradient('z',0.0); 
		delay((retdly-2*pw-2*gt6-1e-5)/2);

	

		rcvron();
		//delay(5e-6);
        	acquire(np1,1/sw); 
		//delay(5e-6);
       		rcvroff();
                      
                delay((retdly-2*pw-2*gt6-1e-5)/2);
       		rgradient('z',Gz4);
       		delay(gt6);
       		rgradient('z',0.0);
		delay(5e-6);
       	 	rgpulse(2*pw,0,rof1,rof2);
		delay(5e-6);
                rgradient('z',Gz4);
       		delay(gt6);
       		rgradient('z',0.0); 
		delay((retdly-2*pw-2*gt6-1e-5)/2);

	

		rcvron();
		//delay(5e-6);
        	acquire(np1,1/sw); 
		//delay(5e-6);
       		rcvroff();
                       
                delay((retdly-2*pw-2*gt6-1e-5)/2);
       		rgradient('z',Gz4);
       		delay(gt6);
       		rgradient('z',0.0);
		delay(5e-6);
       	 	rgpulse(2*pw,two,rof1,rof2);
		delay(5e-6);
                rgradient('z',Gz4);
       		delay(gt6);
       		rgradient('z',0.0); 
		delay((retdly-2*pw-2*gt6-1e-5)/2);

	

		rcvron();
		//delay(5e-6);
        	acquire(np1,1/sw); 
		//delay(5e-6);
       		rcvroff();
                         
                delay((retdly-2*pw-2*gt6-1e-5)/2);
       		rgradient('z',Gz4);
       		delay(gt6);
       		rgradient('z',0.0);
		delay(5e-6);
       	 	rgpulse(2*pw,two,rof1,rof2);
		delay(5e-6);
                rgradient('z',Gz4);
       		delay(gt6);
       		rgradient('z',0.0); 
		delay((retdly-2*pw-2*gt6-1e-5)/2);	
               



}
}

}

