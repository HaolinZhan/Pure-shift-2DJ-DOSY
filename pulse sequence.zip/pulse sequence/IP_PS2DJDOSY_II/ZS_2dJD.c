#ifndef LINT
static char SCCSid[] = "@(#)s2pul.c 19.1 01/13/06 Copyright (c) 1991-1996 Varian Assoc.,Inc. All Rights Reserved";
#endif

/*  s2pul - standard two-pulse sequence */

#include <standard.h>
#include <chempack.h>
static int 	ph1[8] = {0,2,0,2,0,2,0,2},
		ph2[8] = {0,0,0,0,0,0,0,0},
		ph3[8] = {0,0,1,1,2,2,3,3},
		ph4[8] = {0,2,2,0,0,2,2,0},

	        ph12[8] = {0,0,0,0,0,0,0,0},
		ph13[8] = {0,0,0,0,0,0,0,0},
		ph14[8] = {0,0,0,0,0,0,0,0},
		ph15[8] = {0,0,0,0,0,0,0,0};

pulsesequence()
{
	double selpwr,selpw,seltof,selpwr2,selpw2,seltof2,pp,Gz,inhz,inhz1,tau11,nd,na,dd,adj,tau1,gzlvl_ss,gtss,Gs,Gz1,Gz2,Gz3,Gz4,np1,np2,retdly,gt1,gt2,gt3,gt4,gt5,gstab,isjacq,droppts,del,satdly,Del;	double gt0, gzlvl0,gstab0,del0,delcor,isdiff,nid,isbpp,isDoneshot,gzlvl1,gzlvl3,gzlvl4,kappa,oneshot45_flg,isD;
        char   selpat[MAXSTR],satmode[MAXSTR],sspul[MAXSTR];
int prgcycle=(int)(getval("prgcycle")+0.5);	
int i;
	isbpp=getval("isbpp");
	nid=getval("nid");
	isdiff=getval("isdiff");
	gt0=getval("gt0");
	gzlvl0=getval("gzlvl0");
	gstab0=getval("gstab0");
	del0=getval("del0");
	delcor=getval("delcor");
        i = getval("i");
	selpwr = getval("selpwr");
	selpw  = getval("selpw");
	seltof = getval("seltof");
	selpwr2 = getval("selpwr2");
	selpw2  = getval("selpw2");
	seltof2 = getval("seltof2");
	gstab = getval("gstab");
	isjacq = getval("isjacq");
	del = getval("del");
	Del = getval("Del");
	droppts=getval("droppts");
	getstr("selpat",selpat);
	getstr("sspul",sspul);
	gzlvl_ss=getval("gzlvl_ss");		/* steady-state crusher gradient */
    	gtss=getval("gtss");
	inhz   = getval("inhz");
	inhz1   = getval("inhz1");
	tau1   = getval("tau1");
	Gz = getval("Gz");
	Gz1 = getval("Gz1");
	Gz2 = getval("Gz2");
	Gz3 = getval("Gz3");
	Gz4 = getval("Gz4");
	nd = getval("nd");
	na = getval("na");
        dd = getval("dd");
	np1 = getval("np1");
	np2 = getval("np2");
	gt1=getval("gt1");
	gt2=getval("gt2");
	gt3=getval("gt3");
	gt4=getval("gt4");
	gt5=getval("gt5");
	isDoneshot=getval("isDoneshot");
	gzlvl1=getval("gzlvl1");
	gzlvl3=getval("gzlvl3");
	gzlvl4=getval("gzlvl4");
	isD=getval("isD");
	kappa=getval("kappa");
	oneshot45_flg=getval("oneshot45_flg");
	retdly=getval("retdly");
satdly = getval("satdly");
 getstr("satmode",satmode);
  assign(ct,v17);
  assign(zero,v18);
  assign(zero,v19);
 if (getflag("prgflg") && (satmode[0] == 'y') && (prgcycle > 1.5))
    {
        hlv(ct,v17);
        mod2(ct,v18); dbl(v18,v18);
        if (prgcycle > 2.5)
           {
                hlv(v17,v17);
                hlv(ct,v19); mod2(v19,v19); dbl(v19,v19);
           }
     }
	settable(t1,8,ph1);
	settable(t2,8,ph2);
	settable(t3,8,ph3);
  	settable(t4,8,ph4);
  	getelem(t1,v17,v1);
  	getelem(t2,v17,v2);
  	getelem(t3,v17,v3);
  	getelem(t4,v17,v4);
 	assign(v4,oph);
   assign(v4,oph);

   assign(v1,v6);
   add(oph,v18,oph);
   add(oph,v19,oph);
   /* equilibrium period */
   status(A);
  if (sspul[0] == 'y')
      {
                 zgradpulse(gzlvl_ss,gtss);
                 obspower(tpwr);
         rgpulse(1000*1e-6, zero, rof1, 0.0e-6);
         rgpulse(1000*1e-6, one, 0.0e-6, rof1);
                 zgradpulse(gzlvl_ss,gtss*0.6);
      }
 if (satmode[0] == 'y')
     {
        if ((d1-satdly) > 0.02)
                delay(d1-satdly);
        else
                delay(0.02);
	if (getflag("slpsat"))
	   {
		shaped_satpulse("relaxD",satdly,v2);
                if (getflag("prgflg"))
                   shaped_purge(v1,v6,v18,v19);
	   }
	else
	   {
        	satpulse(satdly,v2,rof1,rof1);
		if (getflag("prgflg"))
		   purge(v1,v6,v18,v19);
	   }
     }
   else

   delay(d1);
obsoffset(tof);

/*obspower(selpwr-6);
	rgradient('z',Gz);
	shaped_pulse(selpat,selpw,v1,rof1,rof1);
	rgradient('z',0.0);*/

/*delay(5e-6);
rgradient('z',-Gz*selpw*2000);
delay(2.5e-4);
rgradient('z',0);*/

if (isDoneshot==1)
    {
        zgradpulse(-1.0*gzlvl4,gt4);
        delay(gstab);
    }

obspower(tpwr);
rgpulse(pw, v1, rof1, rof1);

//BPPSTE diffusion
if(isdiff==1)
{

if(isbpp==1)
{zgradpulse(gzlvl0,gt0/2.0);
         delay(gstab0);

	 rgpulse(pw*2.0, v15, rof1, rof1);	

zgradpulse(-1.0*gzlvl0,gt0/2.0);
         delay(gstab0);
}
else
{
zgradpulse(gzlvl0,gt0);
         delay(gstab0);
}

rgpulse(pw, v13, rof1, 0.0);		

        delcor = del0-4.0*pw-3.0*rof1-gt0-2.0*gstab0;
         if (satmode[1] == 'y')
          {
           obspower(satpwr);
           if (satfrq != tof) obsoffset(satfrq);
           rgpulse(delcor,zero,rof1,rof1);
           if (satfrq != tof) obsoffset(tof);
           obspower(tpwr);
          }
         else delay(delcor);     

rgpulse(pw, v14, rof1, 0.0);		

if(isbpp==1)
{zgradpulse(gzlvl0,gt0/2.0);
         delay(gstab0);

	 rgpulse(pw*2.0, v15, rof1, rof1);	

zgradpulse(-1.0*gzlvl0,gt0/2.0);
         delay(gstab0);
}
else
{
zgradpulse(gzlvl0,gt0);
         delay(gstab0);
}

}

//BPPSTE diffusion

if(isD==1)
{
	delay(gstab);
 	zgradpulse(gzlvl3,gt3);	
   	delay((Del-2*pw-gt3)/2);
	rgpulse(pw*2.0, one, rof1, 0.0);
	delay((Del-2*pw-gt3)/2);	
	zgradpulse(gzlvl3,gt3);
	delay(gstab);
   	 
}
if(isDoneshot==1)
{

   if (gt1>0 && gzlvl1>0) 
      {
   	 //rgpulse(pw, one, rof1, 0.0);		/* first 90, v1 */
		 zgradpulse(gzlvl3*(1.0-kappa),gt3/2.0);/*1st main gradient pulse*/
   	 delay(gstab);
	 	 rgpulse(pw*2.0, one, rof1, 0.0);	/* first 180, v2 */
		 zgradpulse(-1.0*gzlvl3*(1.0+kappa),gt3/2.0);/*2nd main grad. pulse*/
   	 delay(gstab);
   	 rgpulse(pw, one, rof1, 0.0);		/* second 90, v3 */

       zgradpulse(gzlvl3*2.0*kappa,gt3/2.0);/* Lock refocussing pulse*/
   	 delay(gstab);

       zgradpulse(gzlvl4,gt4);/* Spoiler gradient balancing pulse */
   	 delay(gstab);

       delcor = Del-4.0*pw-3.0*rof1-2.0*gt3-5.0*gstab-gt4;

       delay(Del-4.0*pw-3.0*rof1-2.0*gt3-5.0*gstab-gt4); /* diffusion delay */

       zgradpulse(2.0*kappa*gzlvl3,gt3/2.0);/*Lock refocussing pulse*/
   	 delay(gstab);
   	 rgpulse(pw, one, rof1, 0.0);		/* third 90, v4 */

       zgradpulse(gzlvl3*(1.0-kappa),gt3/2.0);/*3rd main gradient pulse*/
   	 delay(gstab);
	    rgpulse(pw*2.0, one, rof1, rof1);	/* second 180, v5 */

       zgradpulse(-1.0*(1.0+kappa)*gzlvl3,gt3/2.0);/*4th main grad. pulse*/
	if (oneshot45_flg == 1)
	{
   	 delay(gstab);
	 rgpulse(0.5*pw,one,rof1,rof2);	/* 45-degree pulse, orthogonal to the last 90 */
	}
	else
   	 delay(gstab+2*pw/PI);
      	}
  
}

delay(nid/(sw1*2.0));
//delay(d2/2);
//delay(5e-6);
/*
	zgradpulse(Gz1*0.5,gt1);
	delay(gstab);
	obspower(selpwr);				
	rgradient('z',Gz);					
	shaped_pulse(selpat,selpw, v3, rof1, rof2);	   	
	rgradient('z',0.0);					
	delay(gstab);
	zgradpulse(Gz1*0.5,gt1);
	delay(gstab);
	delay(gstab);
	obspower(tpwr);
	rgpulse(pw*2,v2,rof1,rof2);
	delay(gstab);
	zgradpulse(-Gz1,gt1);
	delay(gstab);
	delay(nid/(sw1*2.0));

*/

/*	delay((0.25/sw1)-gt1-gstab);			
	zgradpulse(Gz1*0.5,gt1);		
	delay(gstab);			
   	rgpulse(pw*2,v2,rof1,rof2);				
	delay(0.25/sw1);
	delay(del);			
	delay(gstab);
	zgradpulse(-Gz1*0.5,gt1);				
	delay(gstab);
	obspower(selpwr);				
	rgradient('z',Gz);					
	shaped_pulse(selpat,selpw, v3, rof1, rof2);	   	
	rgradient('z',0.0);					
	delay(gstab);
	zgradpulse(-Gz1,gt1);				
	delay(gstab-droppts/sw);
	obspower(tpwr);						
	delay(nid/(sw1*2.0));*/

	delay((0.25/sw1) - gt1 - gstab - 2*pw/PI - rof2 - 2*GRADIENT_DELAY - pw - rof1);
	zgradpulse(Gz1,gt1);
	delay(gstab);  
   	obspower(tpwr);
	rgpulse(2*pw,v2,rof1,rof1);
	delay(gstab);
	zgradpulse(Gz1,gt1);
	delay(gstab);
	delay((0.25/sw1) - gt1 - gstab - 2*GRADIENT_DELAY - pw - rof1);
	zgradpulse(Gz2,gt2);
	delay(gstab);
	obspower(selpwr);
	obsoffset(tof);
	rgradient('z',Gz);
	shaped_pulse(selpat,selpw,v3,rof1,rof1);
	rgradient('z',0.0);
	delay(gstab);
	obspower(tpwr);
	zgradpulse(Gz2,gt2);
	delay(gstab - droppts/sw);
	delay(nid/(sw1*2.0));
	//delay(d2/2);



if(isjacq==0)
{ 
  status(C);
             
}
else
{
 /*delay((retdly-2*selpw-2*gt3-1.5e-5)/2);
	zgradpulse(Gz4,gt3);
		delay(5e-6);
       	 	//rgpulse(2*pw,0,rof1,rof2);

	obsoffset(seltof);
	obspower(selpwr);
	shaped_pulse(selpat,selpw,0,rof1,rof1);
	delay(5e-6);
	//delay(5e-6);
	obsoffset(tof);
	rgradient('z',Gz);
	shaped_pulse(selpat,selpw,0,rof1,rof1);
	rgradient('z',0.0);
	delay(5e-6);
	zgradpulse(Gz4,gt3);
	delay((retdly-2*selpw-2*gt3-1.5e-5)/2);	
obspower(tpwr);*/
                           
  status(C);

 for(i=1;i<np2+1;i++)
{
		obsoffset(tof);
		obspower(tpwr);	
		rcvron();
		//delay(5e-6);
        	acquire(np1,1/sw); 
		//delay(5e-6);
       		rcvroff();     
                delay((retdly-2*pw-2*gt5-1e-5)/2);
       		rgradient('z',Gz4);
       		delay(gt5);
       		rgradient('z',0.0);
		delay(5e-6);
       	 	rgpulse(2*pw,0,rof1,rof2);
		delay(5e-6);
                rgradient('z',Gz4);
       		delay(gt5);
       		rgradient('z',0.0); 
		delay((retdly-2*pw-2*gt5-1e-5)/2);

	

		rcvron();
		//delay(5e-6);
        	acquire(np1,1/sw); 
		//delay(5e-6);
       		rcvroff();
                      
                delay((retdly-2*pw-2*gt5-1e-5)/2);
       		rgradient('z',Gz4);
       		delay(gt5);
       		rgradient('z',0.0);
		delay(5e-6);
       	 	rgpulse(2*pw,0,rof1,rof2);
		delay(5e-6);
                rgradient('z',Gz4);
       		delay(gt5);
       		rgradient('z',0.0); 
		delay((retdly-2*pw-2*gt5-1e-5)/2);

	

		rcvron();
		//delay(5e-6);
        	acquire(np1,1/sw); 
		//delay(5e-6);
       		rcvroff();
                       
                delay((retdly-2*pw-2*gt5-1e-5)/2);
       		rgradient('z',Gz4);
       		delay(gt5);
       		rgradient('z',0.0);
		delay(5e-6);
       	 	rgpulse(2*pw,two,rof1,rof2);
		delay(5e-6);
                rgradient('z',Gz4);
       		delay(gt5);
       		rgradient('z',0.0); 
		delay((retdly-2*pw-2*gt5-1e-5)/2);

	

		rcvron();
		//delay(5e-6);
        	acquire(np1,1/sw); 
		//delay(5e-6);
       		rcvroff();
                         
                delay((retdly-2*pw-2*gt5-1e-5)/2);
       		rgradient('z',Gz4);
       		delay(gt5);
       		rgradient('z',0.0);
		delay(5e-6);
       	 	rgpulse(2*pw,two,rof1,rof2);
		delay(5e-6);
                rgradient('z',Gz4);
       		delay(gt5);
       		rgradient('z',0.0); 
		delay((retdly-2*pw-2*gt5-1e-5)/2);	
               



}
}
}



