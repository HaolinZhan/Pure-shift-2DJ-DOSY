%% Code for IP-PS2DJDOSY-II written by Hao M.Y., Huang Y.Q., Lin E.P., Li C., and et. al.
%% Code parameters for a mixture of three amino acids in inhomogeneous magnetic fields in Fig.3.
%% Different samples and raw data need to adjust the code parameters.

clc;
clear all;
close all;
path='';%add the path of the raw data
% path='C:\Users\86157\Desktop\Raw data\Processing scripts_MATLAB\Figure3_three three amino acids\IP_PS2DJDOSY_II_inhomogeneous.fid';
fn=4096;
fn1=64;
fn2=64;
psyche=0;
isfoldj=0;
isphase=0;
isatuoph=1;
isplot=1;
%Read the some parameters that are required to process the data
Para=getpar(path,'sw','np','np1','np2','retdly','nid','sw1','at','tauPS','chunk1','droppts','lsfid','arraydim','gzlvl0');
sw=Para.sw;
np=Para.np/2;
np1=Para.np1/2;
np2=Para.np2;
retdly=Para.retdly;
ni=size(Para.nid,2);
nd=Para.arraydim/ni;
% ni=Para.nid;
at=Para.at;
sw1=Para.sw1;
isupdatefid=1;

if(psyche==1)
chunk1=0;
else
 %chunk1=Para.chunk1;
chunk1=0;
end
droppts=Para.droppts;
%droppts=1;
lsfid=Para.lsfid;

if(droppts>=0)
 Droppts=droppts;
end

if(lsfid>0 && droppts<0)
   Droppts=lsfid+1; 
end
if(lsfid<=0 && droppts<0)
    Droppts=1;
end

%na1=round(sw/(p1*sw1)+0.5);
na=fix(sw/(sw1)+0.5);
na1=na/2;

if(psyche==1)
    na1=na;
end
if(chunk1>0)
    na1=chunk1;
end

 if(chunk1==0)
    na1=na;
end   

npre=(ni-1)*na+na1;

sw2=1/(2*retdly+2*np1/sw);
%% Read the FID data
acount1=0;
fidfit_abs = zeros(nd,fn);
for kd=1:nd
for k=1:ni
    tic;
    [R,I]=load_fid(path(1:end-4),(kd-1)*ni+k);
    FIDdata=R+1i*I;
    %Reshape the FID data into 2D matrix (np1*np2)
    %Taking the retdly in to account, the matrix is changed to be np1real*np1real;
    np1real=round(np1+retdly*sw+0.5);
    np2real=min(np2/2,round(np/np1real/2+0.5));

    FID2Dodd=zeros(np1real,np2real*2);
%    FID2Deven=zeros(np1real,np2real*2);

    for m=1:4*np2real
        FID2Dodd(:,m)=FIDdata((2*(m-1)*np1real+1):((2*m-1)*np1real));
%        FID2Deven(:,m)=FIDdata(((2*m-1)*np1real+1):(2*m*np1real));       
        
    end
  
    FID3Dodd(k,:,:)=FID2Dodd;
%    FID3Deven(k,:,:)=FID2Deven;

   toc;
   acount1=acount1+1
end

FID2dodd=zeros(ni,np1real);
%FID2deven=zeros(ni,np1real);

Fid2dresume=zeros(2*np2real,npre);
Fidresume=zeros(1,npre);
        
for j=1:4*np2real
    FID2dodd=reshape(FID3Dodd(:,:,j),ni,np1real);
 %   FID2deven=reshape(FID3Deven(:,:,j),ni,np1real);
    %resume2ddat for psychePS
    FIDproc=FID2dodd;
    
  %  FIDproc2=FID2deven;

    Fidresume(1:na1)=FIDproc(1,(Droppts+1):(na1+Droppts));
    
   % Fidresume2(1:na1)=FIDproc2(1,(Droppts+1):(na1+Droppts));
    
   for i=1:(ni-1)

     Fidresume(((i-1)*na+na1+1):(i*na+na1))=FIDproc(i+1,(Droppts+1):(na+Droppts)); 
      %   Fidresume2(((i-1)*na+na1+1):(i*na+na1))=FIDproc2(i+1,(Droppts+1):(na+Droppts)); 
   end
   
   FFTresume=fftshift(fft(Fidresume,fn));

     Fid2dresume(j,:)=Fidresume;
    
end

%%%adding weighting function%%%
% win=0.6;
win=0;
scale=size(Fid2dresume);
t1=1:scale(2);
t2=1:scale(1);
ht1=exp(0*pi.*(t1-t1(round(length(t1)/2)))/(max(t1)-min(t1))).^2;  
ht2=cos(win*pi.*(t2-t2(round(length(t2)/2)))/(max(t2)-min(t2))).^2;
ht1=ht2'.*ht1;

WF_Fid2dresume=Fid2dresume.*ht1;
% Fid3dresume(kd,:,:)=Fid2dresume;
Fid3dresume(kd,:,:)=Fid2dresume;

Fid2dfft=fftshift(fft2(WF_Fid2dresume(:,:),fn2,fn));

Fid2dfftre=flipud(Fid2dfft);
Fid2dfftcom=Fid2dfftre+Fid2dfft;
   
  aaa3=Fid2dfftcom(fn2/2,:);

 k=size(aaa3,2);
       phcf=[0 0];
    for ikk=1:fn2
       aph1dat=Fid2dfftcom(ikk,:);
       [aph1datph,phc0,phc1]=acme(aph1dat,phcf);
       
       Fid2dfftcomph_all(ikk,:)=aph1datph;
        phc0all(ikk)=phc0;
        phc1all(ikk)=phc1;
        
    end
    
 Fid3Dplot= Fid2dfftcomph_all;
 
  aaa_real=real(sum(Fid2dfftcomph_all));
  aaa_abs=abs(sum(Fid2dfftcomph_all));

  fidfit_abs(kd,:)=aaa_abs;
  fidfit_real(kd,:)=aaa_real;

end
   
CS_D = 0;% if parameter=1, using the first PS 1D to calculate diffusion values; if parameter=0, using the 1D projections of PS2DJ to calculate diffusion values;
if CS_D == 1
    Fid2d_D_CS = squeeze(Fid3dresume(:,1,:));
    phcf=[0 0];
    for kd=1
        aph1dat=Fid2d_D_CS(kd,:);
        [aph1datph,phc0,phc1]=acme(aph1dat,phcf); 
        Fid2d_D_CS_ap(kd,:)=aph1datph;
        phc0all(ikk)=phc0;
        phc1all(ikk)=phc1; 
        
        fidfit_abs(kd,:) = abs(fftshift(fft(Fid2d_D_CS_ap,fn)));
        fidfit_real(kd,:) = real(fftshift(fft(Fid2d_D_CS_ap,fn)));
    end
end  

figure(1);
plot(fidfit_real(1,:)); % 1D projection in Fig.3b
% figure(7);
% title('����ֵͶӰ��');
% plot(fidfit_abs(8, :));
%% ------------ TNIPM Diffusion Coefficient Calculation  -----------------
  %%------------------------------ Enping Lin ---------------------------------------
addpath('NovelILT_LEP');
Data = fidfit_abs(8:18,:); % setting
g = Para.gzlvl0(8:18); % setting
boundary=[1720,1750, 1845,1860, 1940,1960, 1975,1995, 2100,2115, 2220,2235, 2330,2350, 2425,2450, 2466,2480];
PeaInd = [1851,1947,1986,2109,2227,2341,2441,2472];
[ d,d_total,err_total,D2D ] = DOSYNewILT( Data,PeaInd,g,1);
% figure(2);
% plot(d_total,'o');
% set(gca,'YDir','reverse')
D2D = D2D/max(D2D(:));
D2D(D2D<0.01) = 0;

%--------------------------------------------------------------------------------------
%% ------------------------------------------------------------------------

percent = zeros(size(d_total));
percent_2D = zeros(size(Fid3Dplot));
for i = 1:1:fn
    left = [];
    right = [];
    if d_total(i) ~= 0
        for j = 1:1:size(boundary')
            if boundary(j)<=i
                    left = horzcat(left,boundary(j));
            end
            if boundary(j)>=i
                right = horzcat(right,boundary(j));
            end
        end
    end
    ll=max(left);  % Determine Peak Boundary
    rr=min(right);
    percent_2D_x = max(real(Fid3Dplot(:,i)));
    for j = ll:1:rr
        percent(j) = fidfit_abs(1,j)/fidfit_abs(1,i);
        for k = 1:size(percent_2D,1)
            percent_2D(k,j) = real(Fid3Dplot(k,j))/percent_2D_x;
        end
        d_total(j) = d_total(i);
        err_total(j)=err_total(i);
    end
end

%% 2D DOSY which is used to choose suitable diffusion range to obtain pure 2DJ profiles of single components

% figure(3);
% contour(D2D,100);
% title('2D DOSY');
% set(gca,'YDir','reverse')

%% 3D map display
% D3D = zeros(horzcat(size(Fid3Dplot),41));
 D3D = zeros([size(Fid3Dplot),size(D2D,1)]);
D_window = ceil(max(d_total)*1e18)*1e-18;
D3D_z = -D_window:D_window/20:D_window; 
for i = 1:1:size(Fid3Dplot,2)
     D1 = d_total(i);
     error = err_total(i);
     if D1 ~= 0  && error ~= 0
         for j = 1:1:size(Fid3Dplot,1)
        D3D(j,i,:) = D2D(:,i) * percent_2D(j,i);
         end
     end
end

D3D1=D3D; %store real 3D values for 2DJ projections

%normalization and filter for 3D map display
x = 1:1:size(D3D1,2);
y = 1:1:size(D3D1,1);
z = 1:1:size(D3D1,3);
[x,y,z] = meshgrid(x,y,z);
[D3D1,setvalue1]=normalization(1700,1760,D3D1);
[D3D1,setvalue2]=normalization(1800,1870,D3D1);
[D3D1,setvalue3]=normalization(1930,1970,D3D1);
[D3D1,setvalue4]=normalization(1971,2000,D3D1);
[D3D1,setvalue5]=normalization(2090,2130,D3D1);
[D3D1,setvalue6]=normalization(2200,2250,D3D1);
[D3D1,setvalue7]=normalization(2300,2380,D3D1);
[D3D1,setvalue8]=normalization(2400,2450,D3D1);
[D3D1,setvalue9]=normalization(2460,2500,D3D1);

for i=1:1:size(D3D1,1)
    for j=1:1:size(D3D1,2)
        for k=1:1:size(D3D1,3)/2
              temp=D3D1(i,j,k);
            D3D1(i,j,k)=D3D1(i,j,401-k);
            D3D1(i,j,401-k)=temp;
        end
    end
end

for i=1:1:size(D3D1,1)
    for j=1:1:size(D3D1,2)
       for k=1:1:401
          if abs(D3D1(i,j,k))<0.299
              D3D1(i,j,k)=0;
          end
       end
    end  
end

% figure(10)
% contourslice(x,y,z,D3D1,1:2:size(D3D1,2),1:2:size(D3D1,1),1:2:size(D3D1,3),5); 
% title('��ʵ��ά��ɢ��');
% view(3); axis tight
% zlim([280,330]),ylim([-20,80]),xlim([1600,2600]),
% box on

%% PS-2DJ profile
F=sum(D3D(:,:,78:110),3);
for i=1:1:size(F,1)
    for j=1:1:size(F,2)
        if(F(i,j)~=0)
            F(i,j)=Fid3Dplot(i,j);
        end
    end
end 

figure(101); title('three amino acids'); contour(real(F),18); % 2DJ in Fig.3c
 
F1=sum(D3D(:,:,78:92),3);
for i=1:1:size(F1,1)
    for j=1:1:size(F1,2)
        if(F1(i,j)~=0)
            F1(i,j)=Fid3Dplot(i,j);
        end
    end
end 
figure(201);title('Thr');contour(real(F1),16); % 2DJ in Fig.3d
figure(202); plot(real(real(F1(:,1852))'));
figure(204); plot(real(real(F1(:,1986))'));
figure(205); plot(real(real(F1(:,2472))'));

F2=sum(D3D(:,:,99:103),3);
for i=1:1:size(F2,1)
    for j=1:1:size(F2,2)
        if(F2(i,j)~=0)
            F2(i,j)=Fid3Dplot(i,j);
        end
    end
end 
figure(301);title('GABA');contour(real(F2),2); % 2DJ in Fig.3e
figure(302); plot(real(real(F2(:,2109))'));
figure(303); plot(real(real(F2(:,2227))'));
figure(304); plot(real(real(F2(:,2341))'));

F3=sum(D3D(:,:,105:110),3);
for i=1:1:size(F3,1)
    for j=1:1:size(F3,2)
        if(F3(i,j)~=0)
            F3(i,j)=Fid3Dplot(i,j);
        end
    end
end 
figure(401);title('ALa');contour(real(F3),2);  % 2DJ in Fig.3f
figure(402); plot(real(real(F3(:,1947))'));
figure(403); plot(real(real(F3(:,2439))'));
