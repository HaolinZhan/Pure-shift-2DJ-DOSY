      %%Code to process traditional J-detected spectra

clc;
clear all;
close all;


% path='X:\data\2019.11.2\psyche_oneshot_2dj_grad=20_nid=20_nt=8.fid';
% path='X:\data\2019.10.23\psyche_oneshot_2dj_grad=20_nid=20_nt=8.fid';%��������Ҷ����ݨϩ
% path='X:\data\2019.10.19\psyche_oneshot_2dj_grad=20_nid=40_nt=8.fid';%thresh = 1.68e7;
% path='X:\data\2019.7.13\psyche_oneshot_2dj_nid=20_grad=20_nt=8.fid';%treash=1.5e7
path='X:\data\psyche_oneshot_2dj_nid=20_nt=8.fid';%treash=1.05e7ȥ����һ���㣬������ͼ��ʼ[9.0285, 9.065](real=7,win=0.7),;[9.3, 10](real=13,win=0.8)
% % %[7.695, 8.76](real=15,win=0.6)
% path='C:\Users\lc\Desktop\psyche_oneshot_2dj_nid=20_grad_nt=16.fid';%treash=7e7;
% path='X:\data\2019.10.8\psyche_oneshot_2dj_nid=20_grad=20_nt=4.fid';%treash=7e6 ȥ����һ���� [0.95, 0.964]��[1.058, 1.072]��[1.098, 1.3]
fn=4096;
fn1=64;
fn2=64;
psyche=0;
isfoldj=0;
isphase=0;
isatuoph=1;
isplot=1;
%Read the some parameters that are required to process the data
Para=getpar(path,'sw','np','np1','np2','retdly','nid','sw1','at','tauPS','chunk1','droppts','lsfid','arraydim','gzlvl3');

sw=Para.sw;
np=Para.np/2;
np1=Para.np1/2;
np2=Para.np2;
retdly=Para.retdly;
ni=size(Para.nid,2);
% ni=40;
nd=Para.arraydim/ni;
% nd=20;
% ni=Para.nid;
% nd=1;
at=Para.at;
sw1=Para.sw1;
isupdatefid=1;

if(psyche==1)
chunk1=0;
else
    %chunk1=Para.chunk1;
chunk1=0;
end
droppts=Para.droppts;
%droppts=1;
lsfid=Para.lsfid;

if(droppts>=0)
 Droppts=droppts;
end

if(lsfid>0 && droppts<0)
   Droppts=lsfid+1; 
end
if(lsfid<=0 && droppts<0)
    Droppts=1;
end


%na1=round(sw/(p1*sw1)+0.5);
na=fix(sw/(sw1)+0.5);
na1=na/2;

if(psyche==1)
    na1=na;
end
if(chunk1>0)
    na1=chunk1;
end

 if(chunk1==0)
    na1=na;
end   

npre=(ni-1)*na+na1;

sw2=1/(2*retdly+2*np1/sw);

% f1=linspace(-sw1/2,sw1/2,fn1);
% f2=linspace(-sw2/2,sw2/2,fn2);
% f=linspace(-sw/2,sw/2,fn);

%Read the FID data

acount1=0;
fidfit_abs = zeros(nd,fn);
for kd=1:nd
for k=1:ni
    tic;
    [R,I]=load_fid(path(1:end-4),(kd-1)*ni+k);
    FIDdata=R+1i*I;
    %Reshape the FID data into 2D matrix (np1*np2)
    %Taking the retdly in to account, the matrix is changed to be np1real*np1real;
    np1real=round(np1+retdly*sw+0.5);
    np2real=min(np2/2,round(np/np1real/2+0.5));

%     FID2Dodd=zeros(np1real,np2real*2);
%    FID2Deven=zeros(np1real,np2real*2);

    for m=1:4*np2real
        FID2Dodd(:,m)=FIDdata((2*(m-1)*np1real+1):((2*m-1)*np1real));
 %       FID2Deven(:,m)=FIDdata(((2*m-1)*np1real+1):(2*m*np1real));       
        
    end

    
    FID3Dodd(k,:,:)=FID2Dodd;
  %  FID3Deven(k,:,:)=FID2Deven;
   toc;
   acount1=acount1+1
end


FID2dodd=zeros(ni,np1real);
%FID2deven=zeros(ni,np1real);


    Fid2dresume=zeros(2*np2real,npre);
        Fidresume=zeros(1,npre);
        
for j=1:4*np2real
    FID2dodd=reshape(FID3Dodd(:,:,j),ni,np1real);
 %   FID2deven=reshape(FID3Deven(:,:,j),ni,np1real);
    %resume2ddat for psychePS
    FIDproc=FID2dodd;
    
  %  FIDproc2=FID2deven;

    Fidresume(1:na1)=FIDproc(1,(Droppts+1):(na1+Droppts));
    
   % Fidresume2(1:na1)=FIDproc2(1,(Droppts+1):(na1+Droppts));
    
   for i=1:(ni-1)

     Fidresume(((i-1)*na+na1+1):(i*na+na1))=FIDproc(i+1,(Droppts+1):(na+Droppts)); 
     
  %   Fidresume2(((i-1)*na+na1+1):(i*na+na1))=FIDproc2(i+1,(Droppts+1):(na+Droppts)); 
   end

   
   
   FFTresume=fftshift(fft(Fidresume,fn));
   
%   FFTresume2=fftshift(fft(Fidresume2,fn));
%     figure(j)
%  plot(abs(FFTresume));
   
     %resume2ddat for psychePS
     Fid2dresume(j,:)=Fidresume;
    
 %    Fid2dresume2(j,:)=Fidresume2;
end

%%%adding weighting function%%%
%  %%add non-windows
win=0;
scale=size(Fid2dresume);
t1=1:scale(2);
t2=1:scale(1);
ht1=exp(0*pi.*(t1-t1(round(length(t1)/2)))/(max(t1)-min(t1))).^2;  
ht2=cos(win*pi.*(t2-t2(round(length(t2)/2)))/(max(t2)-min(t2))).^2;
ht1=ht2'.*ht1;
%a

WF_Fid2dresume=Fid2dresume.*ht1;
% Fid3dresume(kd,:,:)=Fid2dresume;
Fid3dresume(kd,:,:)=WF_Fid2dresume;

%%%adding weighting function%%%

%Fid_D_CS(kd,:)=Fid3D

 
Fid2dfft=fftshift(fft2(Fid2dresume(:,:),fn2,fn));
if kd == 1
 figure(1);
 contour(real(Fid2dfft),50);
end


Fid2dfftre=flipud(Fid2dfft);

 Fid2dfftcom=Fid2dfftre+Fid2dfft;
  if kd==1
      Fid3Dplot = Fid2dfftcom;
      flag=0;
       figure(2);
 contour(real(Fid2dfftcom),10);
 
 figure(3);
 plot(real(sum(Fid2dfftcom))) 
  end
 
 
 
  aaa3=Fid2dfftcom(fn2/2,:);

 k=size(aaa3,2);
       phcf=[0 0];
    for ikk=1:fn2
       aph1dat=Fid2dfftcom(ikk,:);
       [aph1datph,phc0,phc1]=acme(aph1dat,phcf);
       
       Fid2dfftcomph_all(ikk,:)=aph1datph;
        phc0all(ikk)=phc0;
        phc1all(ikk)=phc1;
        
    end
    Fid3Dplot= Fid2dfftcomph_all;
    
 %%phase adjust
 if(isatuoph==1)
      figure(4);
 contour(real(Fid2dfftcomph_all),10);
 
 figure(5);
 plot(real(sum(Fid2dfftcomph_all))) 
     
 end
     
%   phc0= phc0all(fn2/2);
%   phc1=phc1all(fn2/2);
%   for iik=1:fn2
%  aph1d=dephase_fun(Fid2dfftcom(iik,:),phc0,phc1);
%  Fid2dfftcomph(iik,:)=aph1d;
%   end
  
  aaa_real=real(sum(Fid2dfftcomph_all));
  aaa_abs=abs(sum(Fid2dfftcomph_all));

  fidfit_abs(kd,:)=aaa_abs;
  fidfit_real(kd,:)=aaa_real;
%   phcf=[0 0];
%     for pd=1
%         aph1dat=fidfit_real(pd,:);
%         [aph1datph,phc0,phc1]=acme(aph1dat,phcf); 
%         fidfit_real_ap(pd,:)=aph1datph;
%         phc0all(ikk)=phc0;
%         phc1all(ikk)=phc1; 
%         fidfit_real(pd,:) = real(fftshift(fft(fidfit_real_ap,fn)));
%     end
end

CS_D = 0;%���ô˲���Ϊ1������ѡ��δ�ؽ��ɶ�άJ�׵ĵ�һ�Ŵ���ѧλ���׽��м��㣻����Ϊ0,����ö�άJ��ͶӰ�׼���
if CS_D == 1
    Fid2d_D_CS = squeeze(Fid3dresume(:,1,:));
    phcf=[0 0];
    for kd=1
        aph1dat=Fid2d_D_CS(kd,:);
        [aph1datph,phc0,phc1]=acme(aph1dat,phcf); 
        Fid2d_D_CS_ap(kd,:)=aph1datph;
        phc0all(ikk)=phc0;
        phc1all(ikk)=phc1; 
        
        fidfit_abs(kd,:) = abs(fftshift(fft(Fid2d_D_CS_ap,fn)));%����ѧλ���׵ľ���ֵģʽ
        fidfit_real(kd,:) = real(fftshift(fft(Fid2d_D_CS_ap,fn)));%����ѧλ���׵�����ģʽ
    end
end

figure(6);
plot(fidfit_real(1,:));
figure(7);
title('����ֵͶӰ��');
plot(fidfit_abs(2,:));

thresh = 8e6;
[d,d_total,boundary,err_total]=dosyfit(fidfit_abs(2:20,:),thresh,Para.gzlvl3(2:20));%����dosyfit������ɢֵ
%fidplot = fidfit_abs;
%x = Para.gzlvl0;
%  
% kd=1;
% Fid2dfft=fftshift(fft2(WF_Fid2dresume(:,:),fn2,fn));
% if kd == 1
%  figure(1);
%  contour(real(Fid2dfft),50);
% end
% 
% 
% Fid2dfftre=flipud(Fid2dfft);
% 
%  Fid2dfftcom=Fid2dfftre+Fid2dfft;
%   if kd==1
%       Fid3Dplot = Fid2dfftcom;
%       flag=1;
%   end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%�˲������ڼ�������׷����״��ʵ����ά��ɢֵ����ʾ���д����ƣ�%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
percent = zeros(size(d_total));
percent_2D = zeros(size(Fid3Dplot));
for i = 1:1:fn
    left = [];
    right = [];
    if d_total(i) ~= 0
        for j = 1:1:size(boundary')
            if boundary(j)<=i
                    left = horzcat(left,boundary(j));
            end
            if boundary(j)>=i
                right = horzcat(right,boundary(j));
            end
        end
    end
    ll=max(left);
    rr=min(right);
    percent_2D_x = max(real(Fid3Dplot(:,i)));
    for j = ll:1:rr
        percent(j) = fidfit_abs(1,j)/fidfit_abs(1,i);
        for k = 1:size(percent_2D,1)
            percent_2D(k,j) = real(Fid3Dplot(k,j))/percent_2D_x;
        end
        d_total(j) = d_total(i);%*pecent;
        err_total(j)=err_total(i);%*pecent;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%% �����ά��,�������ԣ������׷���ȣ���%%%%%%%%%%%%%%%%%
D2D = zeros(fn,501);
D_window = ceil(max(d_total)*1e18)*1e-18;
D2D_x = -D_window:D_window/250:D_window; 
for i = 1:1:fn
    D1 = d_total(i);
    error = err_total(i);
    if D1 ~= 0  && error ~= 0
        
        D2D(i,:) = normpdf(D2D_x, D1,error*1e-19)'.*percent(i);
    end
end

figure(8);
contour(D2D',20);
title('��ά��ɢ��');
set(gca,'YDir','reverse')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Fid3Dplot1=Fid3Dplot;
Fid2dfft1=Fid2dfft;


%%%%%%%%%%%%%%%%%%%%%%%%%%����ά��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
D3D = zeros(horzcat(size(Fid3Dplot),101));
D_window = ceil(max(d_total)*1e18)*1e-18;
D3D_z = -D_window:D_window/50:D_window; 
for i = 1:1:size(Fid3Dplot,2)
     D1 = d_total(i);
     error = err_total(i);
     if D1 ~= 0  && error ~= 0
         for j = 1:1:size(Fid3Dplot,1)
            %D3D(j,i,:) = normpdf(D3D_z, D1, error*1e-18)'*percent(i);
            D3D(j,i,:) = normpdf(D3D_z, D1, error*1e-18)'*percent_2D(j,i);
         end
     end
end

x = 1:1:size(D3D,2);
y = 1:1:size(D3D,1);
z = 1:1:size(D3D,3);
[x,y,z] = meshgrid(x,y,z);

% figure(9)
% contourslice(x,y,z,D3D,[],size(D3D(1,:,1)),[],20)
% title('α��ά��ɢ��');%(��ʵ��ά�׵�һ������)
% view(3); axis tight
% box on 

figure(10)
contourslice(x,y,z,D3D,1:2:size(D3D,2),1:2:size(D3D,1),1:2:size(D3D,3),5);
title('��ʵ��ά��ɢ��');
view(3); axis tight
box on
%set(phandles,'LineWidth',2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%ѡ��������ʾ���д����ƣ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% d_show = [0.90169, 0.9066].*1e-17;%�����С
d_show = [1.2,1.3135].*1e-17;%�����С
D2D_show = Fid3Dplot;
for i = 1:1:size(Fid3Dplot,2)
     D1= d_total(i);
     if  D1 <= d_show(1) || D1 >= d_show(2)
         D2D_show(:,i) = zeros(size(Fid3Dplot,1),1);%Fid3Dplot(:,1);
     end
end
  figure(11);
 title('ѡ������ͶӰ��');
 contour(real(D2D_show),j);

 figure(12);
 title('ԭ��ά��');
 contour(real(Fid3Dplot),10);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
kd=1;
Fid2dfft=fftshift(fft2(WF_Fid2dresume(:,:),fn2,fn));
if kd == 1
 figure(13);
 contour(real(Fid2dfft),50);
end


Fid2dfftre=flipud(Fid2dfft);

 Fid2dfftcom=Fid2dfftre+Fid2dfft;
  if kd==1
      Fid3Dplot = Fid2dfftcom;
      flag=2;
  end
  
  
  aaa3=Fid2dfftcom(fn2/2,:);

 k=size(aaa3,2);
       phcf=[0 0];
    for ikk=1:fn2
       aph1dat=Fid2dfftcom(ikk,:);
       [aph1datph,phc0,phc1]=acme(aph1dat,phcf);
       
       Fid2dfftcomph_all(ikk,:)=aph1datph;
        phc0all(ikk)=phc0;
        phc1all(ikk)=phc1;
        
    end
     Fid3Dplot= Fid2dfftcomph_all;
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%�˲������ڼ�������׷����״��ʵ����ά��ɢֵ����ʾ���д����ƣ�%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
percent = zeros(size(d_total));
percent_2D = zeros(size(Fid3Dplot));
for i = 1:1:fn
    left = [];
    right = [];
    if d_total(i) ~= 0
        for j = 1:1:size(boundary')
            if boundary(j)<=i
                    left = horzcat(left,boundary(j));
            end
            if boundary(j)>=i
                right = horzcat(right,boundary(j));
            end
        end
    end
    ll=max(left);
    rr=min(right);
    percent_2D_x = max(real(Fid3Dplot(:,i)));
    for j = ll:1:rr
        percent(j) = fidfit_abs(1,j)/fidfit_abs(1,i);
        for k = 1:size(percent_2D,1)
            percent_2D(k,j) = real(Fid3Dplot(k,j))/percent_2D_x;
        end
        d_total(j) = d_total(i);%*pecent;
        err_total(j)=err_total(i);%*pecent;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%% �����ά��,�������ԣ������׷���ȣ���%%%%%%%%%%%%%%%%%
D2D = zeros(fn,501);
D_window = ceil(max(d_total)*1e18)*1e-18;
D2D_x = -D_window:D_window/250:D_window; 
for i = 1:1:fn
    D1 = d_total(i);
    error = err_total(i);
    if D1 ~= 0  && error ~= 0
        
        D2D(i,:) = normpdf(D2D_x, D1,error*1e-18)'.*percent(i);
    end
end

figure(14);
contour(D2D',20);
title('��ά��ɢ��');
set(gca,'YDir','reverse')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%%%%%%%%����ά��%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
D3D = zeros(horzcat(size(Fid3Dplot),101));
D_window = ceil(max(d_total)*1e18)*1e-18;
D3D_z = -D_window:D_window/50:D_window; 
for i = 1:1:size(Fid3Dplot,2)
     D1 = d_total(i);
     error = err_total(i);
     if D1 ~= 0  && error ~= 0
         for j = 1:1:size(Fid3Dplot,1)
            %D3D(j,i,:) = normpdf(D3D_z, D1, error*1e-18)'*percent(i);
            D3D(j,i,:) = normpdf(D3D_z, D1, error*1e-18)'*percent_2D(j,i);
         end
     end
end

x = 1:1:size(D3D,2);
y = 1:1:size(D3D,1);
z = 1:1:size(D3D,3);
[x,y,z] = meshgrid(x,y,z);
[D3D,setvalue1]=normalization(1600,1700,D3D);
[D3D,setvalue2]=normalization(1800,1850,D3D);
[D3D,setvalue3]=normalization(1851,1900,D3D);
[D3D,setvalue4]=normalization(1901,2000,D3D);
[D3D,setvalue5]=normalization(2000,2100,D3D);
[D3D,setvalue6]=normalization(2100,2200,D3D);
[D3D,setvalue7]=normalization(2200,2300,D3D);
[D3D,setvalue8]=normalization(2300,2400,D3D);
[D3D,setvalue9]=normalization(2400,2500,D3D);
% figure(9)
% contourslice(x,y,z,D3D,[],size(D3D(1,:,1)),[],20)
% title('α��ά��ɢ��');%(��ʵ��ά�׵�һ������)
% view(3); axis tight
% box on 
% setvalue=600000000000;
% D3D2=D3D;
% temp=0;

for i=1:1:size(D3D,1)
    for j=1:1:size(D3D,2)
       for k=1:1:size(D3D,3)
          if abs(D3D(i,j,k))<0.299
              temp=D3D(i,j,k);
              D3D(i,j,k)=0;
          end
       end
    end  
end
D3D=normalization1(2300,2400,D3D,100000000000000000000);
D3D=normalization1(2400,2500,D3D,100000000000000000000);
temp=D3D(3,2283,68)
for i=1:1:size(D3D,1)
    for j=1:1:size(D3D,2)
        for k=1:1:size(D3D,3)/2
            D3D(i,j,k)=D3D(i,j,101-k);
            D3D(i,j,101-k)=0;
        end
    end
end
for i=1:1:size(D3D,1)
    for j=1:1:size(D3D,2)
       for k=1:1:size(D3D,3)
          if abs(D3D(i,j,k))<0.299
              temp=D3D(i,j,k);
              D3D(i,j,k)=0;
          end
       end
    end  
end
for i=1:1:size(D3D,1)
    for j=1600:1:1700
       for k=1:1:size(D3D,3)
          if abs(D3D(i,j,k))<10
              temp=D3D(i,j,k);
              D3D(i,j,k)=0;
          end
       end
    end  
end
D3D(1,1500,20)=0.00001;
D3D(64,2800,(size(D3D,3)+1)/2)=0.00001;
% setvalue=2280000000000000000;
% for i=1:1:size(D3D,1)
% for j=2400:1:size(D3D,2)
%    for k=1:1:size(D3D,3)
%       if abs(D3D2(i,j,k))<setvalue
%           temp=D3D2(i,j,k);
%           D3D2(i,j,k)=0;
%       end
%    end
%     
% end
% 
% 
% end
% 
% 
% 
% setvalue=2280000000000000000;
% for i=1:1:size(D3D,1)
% for j=2300:1:2400
%    for k=70:1:size(D3D,3)
%       if abs(D3D2(i,j,k))<setvalue
%           temp=D3D2(i,j,k);
%           D3D2(i,j,k)=0;
%       end
%    end
%     
% end
% 
% 
% end
% 
% setvalue=24000000000000000;
% for i=1:1:size(D3D,1)
% for j=1900:1:2000
%    for k=1:1:size(D3D,3)
%       if abs(D3D2(i,j,k))<setvalue
%           temp=D3D2(i,j,k);
%           D3D2(i,j,k)=0;
%       end
%    end
%     
% end
% 
% 
% end
% 
% setvalue=5000000000000000000;
% for i=1:1:size(D3D,1)
% for j=1600:1:1700
%    for k=1:1:size(D3D,3)
%       if abs(D3D2(i,j,k))<setvalue
%           temp=D3D2(i,j,k);
%           D3D2(i,j,k)=0;
%       end
%    end
%     
% end
% 
% 
% end

% setvalue=D3D2(12,1803,67);
% for i=1:1:size(D3D,1)
% for j=1:1:size(D3D,2)
%    for k=1:1:size(D3D,3)
%       if abs(D3D2(i,j,k))<setvalue
%           D3D2(i,j,k)=0;
%       end
%    end
%     
% end
% 

% end

%  D3D2(abs(D3D)<setvalue)=0;
%  D3D2(1,1,70)=0.001;
%  D3D2(size(D3D,1),size(D3D,2),101)=0.001;
% for n=1:1:30
figure(15)
contourslice(x,y,z,D3D,1:2:size(D3D,2),1:2:size(D3D,1),1:2:size(D3D,3),10);
title('��ʵ��ά��ɢ��');
view(3); axis tight
box on
% end
%set(phandles,'LineWidth',2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%ѡ��������ʾ���д����ƣ�%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% d_show = [0.90169, 0.9066].*1e-17;%�����С
% d_show = [9.4,9.8].*1e-18;%�����Сwin=0.7
% d_show = [7.679,8.902].*1e-18;%�����Сwin=0.6
d_show = [9.01297,9.0895].*1e-18;%�����Сwin=0.7
% d_show = [9.65,11].*1e-18;%�����Сwin=0.6
%  d_show = [1.2,1.3135].*1e-17;%�����Сwin=0.6
%  d_show = [1.346,1.5].*1e-17;%�����Сwin=0.6
D2D_show = Fid3Dplot;
% Fid3Dplot=normalization2D(1600,1700,Fid3Dplot);
% Fid3Dplot=normalization2D(1800,1850,Fid3Dplot);
% Fid3Dplot=normalization2D(1851,1900,Fid3Dplot);
% Fid3Dplot=normalization2D(1901,2000,Fid3Dplot);
% Fid3Dplot=normalization2D(2000,2100,Fid3Dplot);
% Fid3Dplot=normalization2D(2100,2200,Fid3Dplot);
% Fid3Dplot=normalization2D(2200,2300,Fid3Dplot);
% Fid3Dplot=normalization2D(2300,2400,Fid3Dplot);
% Fid3Dplot=normalization2D(2400,2500,Fid3Dplot);
% D2D_show = Fid3Dplot;
for i = 1:1:size(Fid3Dplot,2)
     D1= d_total(i);
     if  D1 <= d_show(1) || D1 >= d_show(2)
         D2D_show(:,i) = zeros(size(Fid3Dplot,1),1);%Fid3Dplot(:,1);
     end
end

%  for j=1:1:50
%  figure();
%  title('ѡ������ͶӰ��');
%  contour(abs(D2D_show),j);
%  end

 for j=1:1:30
 figure();
 title('ѡ������ͶӰ��');
 contour(real(D2D_show),j);
end
 
 figure();
 title('ԭ��ά��');
 contour(real(Fid3Dplot),10);