function D2D2=normalization2D(start,over,D2D)
setvalue=0;
D2D2=D2D;
for i=1:1:size(D2D2,1)
    for j=start:1:over
        if abs(D2D2(i,j))>setvalue
               setvalue=abs(D2D2(i,j)); 
        end
    end  
end
if setvalue~=0
    for i=1:1:size(D2D2,1)
        for j=start:1:over
                D2D2(i,j)=D2D2(i,j)/setvalue;
        end  
    end
end