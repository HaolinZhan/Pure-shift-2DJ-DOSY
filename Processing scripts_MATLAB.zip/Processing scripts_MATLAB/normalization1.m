function D3D2=normalization1(start,over,D3D,quan)
D3D2=D3D;
for i=1:1:size(D3D2,1)
   for j=start:1:over
      for k=1:1:size(D3D2,3)
         D3D2(i,j,k)=D3D2(i,j,k)*quan;
      end
   end
end