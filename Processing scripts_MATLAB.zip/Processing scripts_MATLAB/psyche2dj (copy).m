%%Code to process traditional J-detected spectra

clc;
clear all;
close all;

FIDpath='/home/hyq/vnmrsys/data/2016/psyche2dj/dingzhi/psyche2dj_ni=40_np1=195_np2=70_fa8_.fid';

%setting parameter
fn=4096;
fn1=256;
fn2=70;
psyche=1;
%Read the some parameters that are required to process the data
Para=getpar(FIDpath,'sw','np','np1','np2','retdly','ni','sw1','at','tauPS','chunk1','droppts','lsfid');

sw=Para.sw;
np=Para.np;
np1=Para.np1/2;
np2=Para.np2;
retdly=Para.retdly;
ni=Para.ni;
at=Para.at;
sw1=Para.sw1;
isupdatefid=1;

if(psyche==1)
chunk1=0;
else
    chunk1=Para.chunk1;
end
droppts=Para.droppts;
lsfid=Para.lsfid;

if(droppts>=0)
 Droppts=droppts;
end

if(lsfid>0 && droppts<0)
   Droppts=lsfid+1; 
end
if(lsfid<=0 && droppts<0)
    Droppts=1;
end


%na1=round(sw/(p1*sw1)+0.5);
na=fix(sw/(sw1)+0.5);
na1=na/2;

if(chunk1>0)
    na1=chunk1;
end

 if(chunk1==0)
    na1=na;
end   

npre=(ni-1)*na+na1;

sw2=1/(2*retdly+2*np1/sw);

f1=linspace(-sw1/2,sw1/2,fn1);
f2=linspace(-sw2/2,sw2/2,fn2);
f=linspace(-sw/2,sw/2,fn);

%Read the FID data

acount1=0;

for k=1:ni;
    tic;
    [R,I]=load_fid(FIDpath(1:end-4),k);
    FIDdata=R+1i*I;


    %Reshape the FID data into 2D matrix (np1*np2)
    %Taking the retdly in to account, the matrix is changed to be np1real*np1real;
    np1real=round(np1+retdly*sw);
    np2real=min(np2/2,round(np/np1real/2));

    FID2Dodd=zeros(np1real,np2real*2);
   % FID2Deven=zeros(np1real,np2real*2);

    for m=1:2*np2real
        FID2Dodd(:,m)=FIDdata((2*(m-1)*np1real+1):((2*m-1)*np1real));
        %FID2Deven(:,m)=FIDdata(((2*m-1)*np1real+1):(2*m*np1real))       
        
    end

    
    FID3Dodd(k,:,:)=FID2Dodd;
    %FID3Deven(k,:,:)=FID2Deven;
   toc;
   acount1=acount1+1
end

FID2dodd=zeros(ni,np1real);



    Fid2dresume=zeros(2*np2real,fn);
        Fidresume=zeros(1,npre);
        
for j=1:2*np2real
    FID2dodd=reshape(FID3Dodd(:,:,j),ni,np1real);
    
    %resume2ddat for psychePS
    FIDproc=FID2dodd;

    Fidresume(1:na1)=FIDproc(1,(Droppts+1):(na1+Droppts));
   for i=1:(ni-1)

     Fidresume(((i-1)*na+na1+1):(i*na+na1))=FIDproc(i+1,(Droppts+1):(na+Droppts)); 
   end
   
%      FFTresume=fftshift(fft(Fidresume,fn));
%      figure(j)
%        plot(abs(FFTresume));
%    
     %resume2ddat for psychePS
     Fid2dresume(j,1:npre)=Fidresume;
    Fid2dresume(j,npre+1:fn)=0;
     
     
end

Fid2dfft=fftshift(fft2(Fid2dresume(:,:),fn2,fn));


 figure(100);
 contour(abs(Fid2dfft),30);
 
 figure(101);
 plot(abs(sum(Fid2dfft)))
 
 
 if(isupdatefid==1)
    %%Fidpath without the suffix ".fid"
%updatedFidpath='D:\Research\My paper in working\iMQC_DOSY\processing test\writebacked data\fid1d_np=2048';
%updatedFidpath='G:\backup\data\Dbpste_biding_gzarray=20_3k_20k_np=8192';
updatedFidpath='/home/hyq/vnmrsys/data/2016/psyche2dj/writebackdata/normal2dj_ni=70_np=8192';
%updatedFidpath='/home/hyq/vnmrsys/zerodata/processing for dynamic/DOSY/writebacked data/Dbpste_biding_gzarray=25_3k_20k_np=8192';



[M,N]=size(Fid2dresume);
for k=1:M
updateFIDfile(updatedFidpath,Fid2dresume(k,:),k);
end


end  
 
% % 
% %[R,I]=load_fid(FIDpath(1:end-4),100);
% %FIDdata=R+1i*I;
% 
% %Reshape the FID data into 2D matrix (np1*np2)
% %Taking the retdly in to account, the matrix is changed to be np1real*np1real;
% np1real=round(np1+retdly*sw);
% np2real=min(np2/2,round(np/np1real/2));
% 
% % for m=1:np2real
% %     FID2D(:,2*m-1)=FIDdata(((m-1)*np1real+1):(m*np1real));
% %     FID2D(:,2*m)=fliplr(FIDdata((m*np1real+1):((m+1)*np1real)));
% % end
% % 
% % figure();
% % contour(abs(FID2D),80);
% % figure();
% % contour(abs(fftshift(fft2(FID2D(1:np1,:),512,512))),10);
% 
% 
% 
% FID2Dodd=zeros(np1real,np2real*2);
% FID2Deven=zeros(np1real,np2real*2);
% 
% for m=1:1:2*np2real
%      FID2D(:,2*m-1)=FIDdata(((m-1)*np1real+1):(m*np1real));
%      FID2D(:,2*m)=fliplr(FIDdata((m*np1real+1):((m+1)*np1real)));
%      
%     FID2Dodd(:,m)=FIDdata((2*(m-1)*np1real+1):((2*m-1)*np1real));
%     FID2Deven(:,m)=FIDdata(((2*m-1)*np1real+1):(2*m*np1real));
% end
% % 
% figure(1);
% contour(abs(FID2Dodd),80);
% 
% figure(2);
% contour(abs(FID2Deven),80);
% 
% figure(3);
% contour(abs(fftshift(fft2(FID2Dodd(1:np1,:),fn,fn1))),10);
% 
% figure(4);
% contour(abs(fftshift(fft2(FID2Deven(1:np1,:),fn,fn1))),20);

% figure(5);
% contour(abs(fftshift(fft2(FID2D(1:np1,:),fn,fn1))),10);


