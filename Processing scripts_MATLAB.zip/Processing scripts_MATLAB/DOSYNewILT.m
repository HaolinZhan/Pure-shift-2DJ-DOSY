function [ d,d_total,err_total, X_Dosy ] = DOSYNewILT( Data,PeaInd,g,PeakOption)
% DOSY New High-Resolution Inverse Laplace Transform Reconstruction
% Parameter Introduction as below

% LD---diffusion encoding time (unit s),  BD-----diffusion time(unit s)
% Data ---------- DOSY Experimental Data with FFT along frequency dimension
% PeakOption ----------- 1 for Peak Height , 0 for Peak Integration 
% g ---------------- Gradient Value




%----------------------Authored by Enping Lin---------------------------
% -----------------------  2020.6.22 ----------------------------------
    Spec = Data(1,:); 
%     PeaNum = length(PeaBou)/2;
    PeaNum = length(PeaInd);
    d_total = zeros(size(Spec));
    err_total = zeros(size(Spec));
    aa =  (0:0.05:20)*1e-5;
    constant = 0.8825e5;
    DifCoe = aa /constant;
    g = g.*g*10^-4;
    K = exp(-g.'*aa);
    for iter=1:size(K,2)
       k_fa(iter) = norm(K(:,iter),2); 
    end    
    K_normal = K*diag(1./k_fa);
    
     
    
    for it = 1:PeaNum
%           SpecSeg = Spec(PeaBou(2*it-1):PeaBou(2*it));
%           PeaIndGro = find( SpecSeg == max( SpecSeg ) ); 
%           PeaInd(it) = PeaIndGro(1);  % Selecting first peak index if more than one maximal values exist
        if PeakOption  
          PeaTem = Data(:,PeaInd(it)); % Peak Heigh Option
        else  
          PeaTem = sum(  Data(:,PeaBou(2*it-1):PeaBou(2*it)),2  ); % Peak Integration Option 
        end
          PeaDat(:,it) =  PeaTem;
    end
    
    %% ---------------------  Algorithm ---------------------------------
    lambda =0.01;  % 0.01 to 0.0001
    rel_tol = 1e-8;
    X_Dosy = zeros(length(aa),length(Spec));
   
%     figure,hold on, title('diffusion coefficient')
    for it = 1:PeaNum
        sn = PeaDat(:,it);
        sn_max = max(sn);
        sn = sn./sn_max;
        %  ------------------  TNIPM ------------------------ 
       [x_rec,status]=l1_ls_nonneg(K_normal,sn,lambda,rel_tol);
        x_rec = diag(1./k_fa)*x_rec*sn_max;
        x_rec =x_rec./max(x_rec);
%         plot(aa,x_rec);
        % --------------------ITAMed ----------------------------
    %     [x_rec,D_scale]=ITAMED(1e4,[min(aa),max(aa),length(aa)],sn,g2,lambda);
    %      x_rec = x_rec./max(x_rec);
       % --------------------------------------------------------  
        d(it) = aa( find( x_rec == max(x_rec)) ) /constant % Diffusion Coefficient Value
        d_total(PeaInd(it)) = d(it); % Filling zero in non-peak position
        err(it) =  (sum(err_total >= 0.5)+1)/2 * (aa(2)-aa(1)) /constant;  % Diffusion Coefficient Value Error
        err_total(PeaInd(it)) = err(it);  % Filling zero in non-peak position
        
        if PeakOption  
             X_Dosy( :,PeaInd(it)-5:PeaInd(it)+5 ) = repmat(x_rec,1,11)*diag( Spec(PeaInd(it)-5:PeaInd(it)+5) );
        else
             X_Dosy( :,PeaBou(2*it-1):PeaBou(2*it) ) = repmat( x_rec,1,PeaBou(2*it)-PeaBou(2*it-1)+1 )*diag( Spec(PeaBou(2*it-1):PeaBou(2*it)) );% Peak Intagration Option
        end
    end
  
     
%     figure,
%       ax1 = axes('position',[0.1 0.75 0.8 0.3]);
%       plot(ax1,(1:length(Spec)),Spec);set(gca,'Xdir','reverse');axis off;
%       xlim([1,length(Spec)]);
%       ax2 = axes('position',[0.1 0.23 0.8 0.5]);
%       contour( (1:length(Spec)) ,DifCoe,X_Dosy,40 ),xlabel('Frequency Index');ylabel('Diffusion Coefficient');
%       set(ax2,'Ydir','reverse','Xdir','reverse'); 
%       xlim([1,length(Spec)]); ylim([DifCoe(1),DifCoe(end)]);
    
end

