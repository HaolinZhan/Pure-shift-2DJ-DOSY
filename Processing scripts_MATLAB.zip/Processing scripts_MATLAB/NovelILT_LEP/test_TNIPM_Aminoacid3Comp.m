%% Authored by Enping Lin
%  High-resolution Laplace Spectra Reconstruction with Sparse Property
%  2020.6.21
%--------------------------------------------------------------------
%--------------------------------------------------------------------
clear all,close all
load('aminoacid3comp.mat');

%% ------------------ Initialization -------------------------------------
dt=abs(NmrData.SPECTRA); % processed experimental data
  if size(dt,1)>size(dt,2)
     dt = dt.';  
  end  
g=100*NmrData.Gzlvl; % gradient values
BD=NmrData.DELTAOriginal; % diffusion time
LD=NmrData.deltaOriginal; % diffusion encoding time
cs=NmrData.Specscale;     % chemical shift
gamma=4257.7; 
g2=(2*pi*gamma*g*LD).^2*(BD-LD/3)*1e4;
g2 = g2*1e-10;
Spec = dt(1,:);
%% ----------------  User Setting -----------------------------

Option = 1; %% To be selected               1 for Peak Height , 0 for Peak Integration
aa = 4:0.1:20;  %% To be selected           Roughly estimeted decay constant range
csr = [min(cs),max(cs)];%% To be selected   Chemical Shift Dimension Show Range
aar = [min(aa),max(aa)];%% To be selected   Diffusion Coefficient Dimension Show Range


figure,hold on,plot(cs,Spec)
if  Option  
    % ------------------------- Peak Heigh Option -----------------------  
    PeaInd = [826,841,888,942,998,1056,1075,1120];%% To be selected
    PeaNum = length(PeaInd);

    % ------------------------- Peak Integation Option ---------------------------
else
    PeaBou = []; %% To be selected
    PeaNum = length(PeaBou)/2;
    Marks = zeros(size(Spec));
    for it = 1:PeaNum
        Marks(PeaBou(2*it-1):PeaBou(2*it)) =0.5*max( Spec(PeaBou(2*it-1):PeaBou(2*it)) ) * ones( 1,PeaBou(2*it)-PeaBou(2*it-1)+1 );
    end
    plot(Marks,'r'),title('Peak Integration Calculation')
end

%% ----------------------------------------------------------------------------
for it = 1:PeaNum
    if Option
      PeaTem = dt(:,PeaInd(it)); % Peak Height Option
    else  
      PeaTem = sum(  dt(:,PeaBou(2*it-1):PeaBou(2*it)),2  ); % Peak Integration Option 
    end
    PeaDat(:,it) =  PeaTem;
    plot( log(PeaTem/max(PeaTem)) )
end

figure,hold on
for it = 1:PeaNum
    PeaTem = dt(:,PeaInd(it));
    PeaDat(:,it) =  PeaTem;
    plot( log(PeaTem/max(PeaTem)) )
end
 
K = exp(-g2.'*aa);
for iter=1:size(K,2)
   k_fa(iter) = norm(K(:,iter),2); 
end    
K_normal = K*diag(1./k_fa);
%% ---------------------  Algorithm ---------------------------------
lambda =0.01;  % 0.01 to 0.0001
rel_tol = 1e-8;
X_Dosy = zeros(length(aa),length(Spec));
for it = 1:PeaNum
    
    sn = PeaDat(:,it);
    sn_max = max(sn);
    sn = sn./sn_max;
    %  ------------------  TNIPM ------------------------ 
   [x_tnipm,status]=l1_ls_nonneg(K_normal,sn,lambda,rel_tol);
    x_tnipm = diag(1./k_fa)*x_tnipm*sn_max;
    x_tnipm =x_tnipm./max(x_tnipm);
    % --------------------ITAMed ----------------------------
%     [x_itamed,D_scale]=ITAMED(1e4,[min(aa),max(aa),length(aa)],sn,g2,lambda);
%      x_itamed =x_itamed./max(x_itamed);
   % --------------------------------------------------------  
    if Option  
         X_Dosy( :,PeaInd(it)-5:PeaInd(it)+5 ) = repmat(x_tnipm,1,11)*diag( Spec(PeaInd(it)-5:PeaInd(it)+5) );
    else
         X_Dosy( :,PeaBou(2*it-1):PeaBou(2*it) ) = repmat( x_tnipm,1,PeaBou(2*it)-PeaBou(2*it-1)+1 )*diag( Spec(PeaBou(2*it-1):PeaBou(2*it)) );% Peak Intagration Option
    end
    
end

%% ---------------------- Display Result --------------------------------------
figure,
      ax1 = axes('position',[0.1 0.75 0.8 0.3]);
      plot(ax1,cs,Spec);set(gca,'Xdir','reverse');axis off;
      xlim([csr(1),csr(2)]);
      ax2 = axes('position',[0.1 0.23 0.8 0.5]);
      contour(ax2,cs,aa,X_Dosy,40);xlabel('Chemical Shift/ppm');ylabel('Diffusion Coefficient/10^-^1^0m^2s^-^1');
      set(ax2,'Ydir','reverse','Xdir','reverse'); 
      xlim([csr(1),csr(2)]); ylim([aar(1),aar(2)]);
%       Comp_pos = [7.5,8.1,8.5];
%       Comp_num = length(Comp_pos);
%       set(ax2,'YTick', Comp_pos);     
%       set(gca,'FontWeight','bold','FontSize',14);
%       for i = 1:Comp_num
%            line(get(ax2,'xlim'),[Comp_pos(i),Comp_pos(i)],'LineWidth',0.8,'color',[0.85 0.85 0.85],'LineStyle','--' );
%       end  