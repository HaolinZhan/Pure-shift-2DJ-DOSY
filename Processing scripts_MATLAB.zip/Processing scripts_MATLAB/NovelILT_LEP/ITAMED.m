function [A_final,D_scale]=ITAMED(iter,diffusion_range,II,KK, lambda)
%Inputs:
%iter maximum number of iterations
%diffusion_range vector of 3 parameters [��Minimal Diffusion,��Maximum diffusion��, ��number of points��]
%II PFG signal (exponential decay)
%KK vector of k in eq I=exp( D?k)
%lambda Lagrangian multiplier
%Outputs:
%A_final ITAMeD result: distribution of diffusion coefficients.
%D_scale diffusion scale vector
D_scale=linspace(diffusion_range(1),diffusion_range(2),diffusion_range(3));
%Defining the Diffusion grid
testsize=size(II);
if testsize(1)~=1
data.II=II';
else
data.II=II;
end
testsize=size(KK);
if testsize(1)~=1
    data.KK=KK';
else
data.KK=KK;
end
data.NmrData.arraydim=size(data.II,2);
matAl=matA_if_nofile(D_scale,data);
%creating \Psi matrix of ILT
A=zeros(size(D_scale));
%initial value of vector A
[A_final]=fista(A, data.II', lambda, matAl,iter);
%Running the fista procedure
sprintf('End of calculations')
end

