function [mata]=matA_if_nofile(D,data)
    size_D=size(D);
    for i=1:size_D(2)
        u=0;
        for j=1:data.NmrData.arraydim
            u=u+1;
            mata(j,i)=exp( -(D(i))*data.KK(u));
        end
    end
end

