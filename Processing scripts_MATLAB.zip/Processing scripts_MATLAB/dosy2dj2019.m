clc;
clear all;
close all;

FIDpath='/home/hyq/vnmrsys/data/zhl/zs_serf/DOSY/20190302/2djdosy.fid';

fn=4096;
fn1=256;
fn2=70;
psyche=1;
%Read the some parameters that are required to process the data
Para=getpar(FIDpath,'sw','np','np1','np2','retdly','ni','sw1','at','tauPS','chunk1','droppts','lsfid','gzlvl1','arraydim');

sw=Para.sw;
np=Para.np/2;
ni=Para.ni;


 nd=Para.arraydim/ni;
at=Para.at;
sw1=Para.sw1;
isupdatefid=1;

if(psyche==1)
chunk1=0;
else
    chunk1=Para.chunk1;
end

lsfid=Para.lsfid;




F1F2F3time=zeros(nd,ni,np);
for m=1:ni
    tic;
   for n=1:nd
       [RE IM ]=load_fid(FIDpath(1:end-4),(m-1)*ni+n);
       fidsignal=RE+1i*IM;
       fidsignal=fidsignal.';
       F1F2F3time(n,m,:)=fidsignal;
   end
   toc;
end


updatedFidpath='/home/hyq/vnmrsys/data/zhl/zs_serf/DOSY/20190302/2djdosy_1';

for k=1:ni
    for l=1:nddssh
        
        updateFIDfile(updatedFidpath,F1F2F3time(l,k,:),(k-1)*ni+l);
    end

end