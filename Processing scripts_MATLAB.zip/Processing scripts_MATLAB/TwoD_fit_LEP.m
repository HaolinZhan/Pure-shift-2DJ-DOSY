%% Code to process dosy spectra;
%% Writen by lichen;
%% 10th,Jan,2018;
%% Version = 1.0;

clc;
clear all;
close all;
%gzlvl1=800,5398,7592,9281,10707,11964,13101,14147,15121,16036,16901,17724,18511,19265,20000
% %���ȼ��飬����߻ૣ�����?
% FIDpath = '/home/hyq/vnmrsys/data/hmy/2019.5.8/model02_nid=20.fid';
% FIDpath='/home/hyq/vnmrsys/data/hmy/2019.5.13/model_nid=15.fid';
% FIDpath='/home/hyq/vnmrsys/data/hmy/2019.5.13/anjisuan/model_20_nid=15.fid';
% FIDpath='/home/hyq/vnmrsys/data/hmy/2019.5.13/anjisuan/bppste_20.fid';
% FIDpath='/home/hyq/vnmrsys/data/hmy/2019.5.13/anjisuan/model03_20_nid=15.fid';
% FIDpath='/home/hyq/vnmrsys/data/hmy/2019.5.15/new/model_nid=20.fid';
% FIDpath='/home/hyq/vnmrsys/data/hmy/20190521/0529/model_20_nid=20.fid';
%  FIDpath='E:\data\hmy\2019.6.1\model_20_nid=20.fid';
FIDpath='X:\ԭ���Ա���\E\���ش���\data\hmy\2019.6.1\model_20_nid=20.fid';

fn = 4096*4;%4096*4;
fn1 = 512;
fn2 = 512;
psyche = 1;


Para = getpar(FIDpath,'sw','np','np1','np2','retdly','ni','ni2','sw1','at','tauPS','droppts','lsfid','arraydim','nid','gzlvl1');
%ni=Para.ni;
np = Para.np;
npre = np/2;
nd = Para.arraydim;
x = Para.gzlvl1./32768.*64;

fidplot = zeros(nd,fn);
f1f2time = zeros(nd,npre);
     

phcf=[0 0];    
for j = 1:nd
    [R,I] = load_fid(FIDpath(1:end-4),j);
    FIDdata = R+1i*I;
    fidsignal = FIDdata.';
    f1f2time(j,:) = fidsignal;
%     subplot(1,nd,j)
%     
%     aph1dat=f1f2time(j,:);
%     [aph1datph,phc0,phc1]=acme(aph1dat,phcf);
%     f1f2time(j,:)=aph1datph;
%     phc0all(j)=phc0;
%     phc1all(j)=phc1;
%     
%     plot(real(fftshift(fft(f1f2time(j,:),fn)))) 
%     fidplot(j,:) = real(fftshift(fft(f1f2time(j,:),fn)));


%      plot(abs(fftshift(fft(f1f2time(j,:),fn)))) 
     fidplot(j,:) = abs(fftshift(fft(f1f2time(j,:),fn)));
end
figure;
plot(fidplot(1,:))
boundary =[];
tresh =2e4;
%****************************************************************************************
addpath('NovelILT_LEP');
Data = fidplot(2:20,:); % setting
g = Para.gzlvl1(2:20); % setting
figure,plot(Data(1,:)),xlabel('Index'),title('Search for boundary point index');
boundary  = [1675,1702, 1790,1811, 1889,1900, 1927,1941, 2030,2063, 2156,2178, 2264,2288, 2353,2384, 2397,2424]; %% setting  Setting peak boundary index according to last figure 
PeaInd = [1691,1803,1896,1935,2053,2169,2279,2375,2407]; % setting     highest peak points index
[ d,d_total,err_total ] = DOSYNewILT( Data,PeaInd,g,1);
figure();
plot(d_total,'o');
%******************************************************************************************
