
path='C:\Users\lc\Desktop\untitled folder\2djdosy.fid';

fn=10000;
fn1=64;
fn2=32;
psyche=0;
isfoldj=0;
isphase=0;
isatuoph=1;
%Read the some parameters that are required to process the data
Para=getpar(path,'sw','np','np1','np2','retdly','ni','sw1','at','tauPS','chunk1','droppts','lsfid','arraydim','gzlvl0');

sw=Para.sw;
np=Para.np/2;
%np1=Para.np1/2;
%np2=Para.np2;
%retdly=Para.retdly;
% ni=size(Para.nid,2);
ni=Para.ni;
nd=Para.arraydim/ni;
% nd=1;
at=Para.at;
sw1=Para.sw1;
isupdatefid=1;

acount1=0;

fidfit_abs = zeros(nd,fn);
for kd=1:nd
for k=1:ni
    tic;
    [R,I]=load_fid(path(1:end-4),(kd-1)*ni+k);
    FIDdata=R+1i*I;
    %Reshape the FID data into 2D matrix (np1*np2)
    %Taking the retdly in to account, the matrix is changed to be np1real*np1real;
    np1real=round(np1+retdly*sw+0.5);

    FID2Dodd=zeros(np1real,np2real*2);
%    FID2Deven=zeros(np1real,np2real*2);
   toc;
end


FID2dodd=zeros(ni,np1real);
%FID2deven=zeros(ni,np1real);


    
for j=1:2*np2real
    FID2dodd=reshape(FID3Dodd(:,:,j),ni,np1real);
 %   FID2deven=reshape(FID3Deven(:,:,j),ni,np1real);
    %resume2ddat for psychePS
    FIDproc=FID2dodd;
    
  %  FIDproc2=FID2deven;

    Fidresume(1:na1)=FIDproc(1,(Droppts+1):(na1+Droppts));
    
   % Fidresume2(1:na1)=FIDproc2(1,(Droppts+1):(na1+Droppts));
    
   for i=1:(ni-1)

     Fidresume(((i-1)*na+na1+1):(i*na+na1))=FIDproc(i+1,(Droppts+1):(na+Droppts)); 
     
  %   Fidresume2(((i-1)*na+na1+1):(i*na+na1))=FIDproc2(i+1,(Droppts+1):(na+Droppts)); 
   end

   
   
   FFTresume=fftshift(fft(Fidresume,fn));
   
%   FFTresume2=fftshift(fft(Fidresume2,fn));
%     figure(j)
%  plot(abs(FFTresume));
   
     %resume2ddat for psychePS
     Fid2dresume(j,:)=Fidresume;
    
 %    Fid2dresume2(j,:)=Fidresume2;
end

Fid3dresume(kd,:,:)=Fid2dresume;


 
Fid2dfft=fftshift(fft2(Fid2dresume(:,:),fn2,fn));
 figure(1);
 contour(real(Fid2dfft),50);


Fid2dfftre=flipud(Fid2dfft);

 Fid2dfftcom=Fid2dfftre+Fid2dfft;
  figure(2);
 contour(real(Fid2dfftcom),10);
 
 figure(3);
 plot(real(sum(Fid2dfftcom))) 
 
 
  aaa3=Fid2dfftcom(fn2/2,:);
 k=size(aaa3,2);
       phcf=[0 0];
    for ikk=1:fn2
       aph1dat=Fid2dfftcom(ikk,:);
       [aph1datph,phc0,phc1]=acme(aph1dat,phcf);
       
       Fid2dfftcomph_all(ikk,:)=aph1datph;
        phc0all(ikk)=phc0;
        phc1all(ikk)=phc1;
        
    end

 %%phase adjust
 if(isatuoph==1)
      figure(4);
 contour(real(Fid2dfftcomph_all),4);
 
 figure(5);
 plot(real(sum(Fid2dfftcomph_all))) 
     
 end
     
  phc0= phc0all(fn2/2);
  phc1=phc1all(fn2/2);
  for iik=1:fn2
 aph1d=dephase_fun(Fid2dfftcom(iik,:),phc0,phc1);
 Fid2dfftcomph(iik,:)=aph1d;
  end
 
  aaa_real=real(sum(Fid2dfftcomph_all));
  aaa_abs=abs(sum(Fid2dfftcomph_all));
  figure(6);
  plot(aaa_real);
  figure(7);
  plot(aaa_abs);
  fidfit_abs(kd,:)=aaa_abs;
  
%   
%   [M,N]=size(aaa);
%   
%   for i=1:M
% aaafidtemp(i,:)=ifftshift(ifft(ifftshift(aaa(i,:))));
% end
% for j=1:N
% aaafid(:,j) = ifftshift(ifft(ifftshift(aaafidtemp(:,j))));
% end
%   
% 
% Fid3dok(kd,:,:)=aaafid;

end  

