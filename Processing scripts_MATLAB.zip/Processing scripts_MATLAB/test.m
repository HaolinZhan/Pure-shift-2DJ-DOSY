close all; clear all; clc

D2D = zeros(horzcat(size(Fid3Dplot),101));
D_window = ceil(max(d_total)*1e18)*1e-18;
D3D_z = -D_window:D_window/50:D_window;
D2D(j,i,:) = normpdf(D3D_z,1,0.5)';



x = 1:1:size(D3D,2);
y = 1:1:size(D3D,1);
z = 1:1:size(D3D,3);
[x,y,z] = meshgrid(x,y,z);

figure(8)
contourslice(x,y,z,D3D,size(D3D(:,1,1)),size(D3D(1,:,1)),size(D3D(1,1,:)))
view(3); axis tight
box on
%set(phandles,'LineWidth',2);